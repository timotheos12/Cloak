@echo off
cd /d "%~dp0"
echo Thank you for using Cloak! Please wait...
echo.
python app.py
echo Cloak has been closed.
echo Press any key to exit.
pause >nul